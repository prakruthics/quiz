import 'package:flutter/material.dart';
imp
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quiz App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: QuizPage(),
    );
  }
}

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int currentQuestionIndex = 0;
  int score = 0;

  // List of questions with options and correct answer
  final List<Map<String, dynamic>> questions = [
    {
      'question': 'What is the capital of France?',
      'options': ['Berlin', 'Madrid', 'Paris', 'Rome'],
      'correctAnswer': 'Paris'
    },
    {
      'question': 'Which planet is known as the Red Planet?',
      'options': ['Earth', 'Mars', 'Jupiter', 'Saturn'],
      'correctAnswer': 'Mars'
    },
    {
      'question': 'What is 2 + 2?',
      'options': ['3', '4', '5', '6'],
      'correctAnswer': '4'
    },
  ];

  // Function to check the answer and update score
  void _checkAnswer(String selectedAnswer) {
    if (selectedAnswer == questions[currentQuestionIndex]['correctAnswer']) {
      setState(() {
        score++;
      });
    }
  }

  // Function to move to the next question
  void _nextQuestion() {
    if (currentQuestionIndex < questions.length - 1) {
      // Delay to give the user a moment to see the result
      Future.delayed(Duration(seconds: 1), () {
        setState(() {
          currentQuestionIndex++;
        });
      });
    } else {
      // If all questions are answered, show the score
      _showScoreDialog();
    }
  }

  // Function to show the score dialog
  void _showScoreDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Quiz Completed"),
          content: Text("Your score is $score/${questions.length}"),
          actions: <Widget>[
            TextButton(
              child: Text("Restart Quiz"),
              onPressed: () {
                setState(() {
                  score = 0;
                  currentQuestionIndex = 0;
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentQuestion = questions[currentQuestionIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text('Quiz App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Question ${currentQuestionIndex + 1}/${questions.length}',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            Text(
              currentQuestion['question'],
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            ...currentQuestion['options'].map<Widget>((option) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 5.0),
                child: ElevatedButton(
                  onPressed: () {
                    _checkAnswer(option);
                    _nextQuestion();
                  },
                  child: Text(option),
                ),
              );
            }).toList(),
            SizedBox(height: 20),
            Text('Score: $score', style: TextStyle(fontSize: 20)),
          ],
        ),
      ),
    );
  }
}
